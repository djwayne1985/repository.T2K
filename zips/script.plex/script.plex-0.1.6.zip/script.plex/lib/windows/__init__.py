import kodigui
from lib import util

kodigui.MONITOR = util.MONITOR
